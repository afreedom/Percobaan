<?php
include("koneksi.php");
$propinsi = $_GET['kota'];
$query = mysql_query("SELECT distinct kecamatan FROM tempat WHERE kota ='$propinsi'");
echo "<select name='kecamatan' id=kecamatan>";
echo "<option value=->--Pilih Kecamatan--</option></select>";
while( $data = mysql_fetch_array( $query ) ){
	echo "<option value='".$data['kecamatan']."'>".$data['kecamatan']."</option>";
}
echo "</select>";
?>
