<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Quick Count</title>
	<script src="http://code.jquery.com/jquery.js"></script>
	
    <link href="style/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="style/bootstrap.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	
	<link href="style/bootstrap-responsive.css" rel="stylesheet">
	<script type="text/javascript">
	function cek_form(){
		var username=document.getElementById('username').value;
		var password=document.getElementById('password').value;
		var kode=document.getElementById('kode').value;
		
		if(username==''){
			alert('Masukan Username Anda!');
			return false;
		} 
		
		if(password==''){
			alert('Masukan Password Anda!');
			return false;
		} 
		
		if(kode==''){
			alert('Masukan Kode!');
			return false;
		} 
	}
	</script>
	 <style type="text/css">
      body {
        padding-top: 40px;
        padding-bottom: 40px;
        background-color: #f5f5f5;
      }

      .form-signin {
        max-width: 300px;
        padding: 19px 29px 29px;
        margin: 0 auto 20px;
        background-color: #fff;
        border: 1px solid #e5e5e5;
        -webkit-border-radius: 5px;
           -moz-border-radius: 5px;
                border-radius: 5px;
        -webkit-box-shadow: 0 1px 2px rgba(0,0,0,.05);
           -moz-box-shadow: 0 1px 2px rgba(0,0,0,.05);
                box-shadow: 0 1px 2px rgba(0,0,0,.05);
      }
      .form-signin .form-signin-heading,
      .form-signin .checkbox {
        margin-bottom: 10px;
      }
      .form-signin input[type="text"],
      .form-signin input[type="password"] {
        font-size: 16px;
        height: auto;
        margin-bottom: 15px;
        padding: 7px 9px;
      }

    </style>
</head>
<body topmargin="0" bottommargin="0">
<?php 
	include ("koneksi.php");
	include ("function/function.php");
	$tampil="ok";
	include ("inc/simple-php-captcha.php"); 
	$_SESSION['captcha'] = captcha();
?>
	
	<?php form_login (); ?>

</body>
</html>