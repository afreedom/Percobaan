<?

include_once 'xmlCreator.php';

global $link;

$kelurahan = $_GET['kelurahan'];
$jokowi = $_GET['jokowi'];
$prabowo = $_GET['prabowo'];
$queryk=mysql_query("select * from quickcount where quickCountKelurahan='$kelurahan' ");
$jum=mysql_num_rows($queryk);
if($jum>0){
$sql_update= "update quickcount set quickCountJokowi='$jokowi',  quickCountPrabowo='$prabowo' where   quickCountKelurahan='$kelurahan'";
$status = mysql_query($sql_update);
}
else{
$sql_insert = "INSERT INTO quickcount(quickCountKelurahan, quickCountJokowi, quickCountPrabowo) VALUES('$kelurahan',$jokowi,$prabowo)";
$status = mysql_query($sql_insert);
}
if($status) {
	echo "OK$jum";
} else {
    echo "FAIL";
}

?>
