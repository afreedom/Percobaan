<?php
function form_login () {

	echo "<div class=container2>";

	echo "<center><img src=\"pict/login.png\" width=300 style=\"margin-bottom:-65px;margin-left:-85px;\"></center><form class=\"form-signin\" action=\"ceklogin.php\" method=post align=center>";
	
		echo "<input name=proses type=hidden value=login>";
		echo "<br><br>";
		echo "<b>USERNAME  &nbsp;&nbsp  &nbsp;&nbsp;</b>";
		
		echo "<input type=text name=username id=username size=25 style=\"text-align:center; background-color:#303030; color:white;\">";
		echo "<br><br>";
		echo "<b>PASSWORD &nbsp;&nbsp  &nbsp;&nbsp;</b>";
		
		echo "<input type=password name=password id=password size=25 style=\"text-align:center; background-color:#303030; color:white;\">";
		echo "<br><br>";
		echo "Masukkan Kode Dibawah Ini<br>";
			 echo '<img src="' . $_SESSION['captcha']['image_src'] . '" alt="CAPTCHA" width=100 />';
	 	 $cap=array();
		$cap=$_SESSION['captcha']['code'];
		echo "<input type=text name=kode id=kode size=10 style=\"text-align:center; background-color:#303030; color:white;\">";
		
		echo "<br><input type=hidden name=cap value=$cap><br>";
		echo "<input name=\"submit\" type=submit value=\"LOGIN\" class=\"btn btn-large btn-primary\" onclick=\"return cek_form();\">";
		echo "<br><br>";
	
	echo "</form>";
	/*echo "<div class=footer>";
		echo "Hak Cipta @ 2011, Technology Solution";
		echo "<div class=footer_sub>Design By <a href=http://www.technos.web.id target=_blank>Technology Solution</a></div>";
	echo "</div>";*/
	echo "</div>";
	
}











?>