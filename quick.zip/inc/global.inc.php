<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$name = 'samarindzoo';
$db = &new MySQL($host,$user,$pass,$name);
?>