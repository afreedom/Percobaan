<?php 
session_start();
$randkode=rand(111111,999999); 
$_SESSION["kode"]=$randkode;
session_register ("kode");
$text=$_SESSION["kode"];
header("Content-type:image/png");
$im=imagecreatefrompng("latar.png");
$white=imagecolorallocate($im, 255, 255, 255);
$font='04B_03B.ttf';
$fontsize=11;
imagettftext($im,$fontsize,0,10,15,$white,$font,$text);
imagepng($im);
imagedestroy($im); 
?> 