<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"> 
<html> 
<head> 
    <title>404 Error - Page Not Found</title> 
</head> 
<body> 
<table style="border: 1px dashed rgb(204, 204, 204);" align="center"
border="0" cellpadding="6" cellspacing="0" width="800"> 
<tr> 
<td style="font-family: Arial,Helvetica,sans-serif; font-size: 12px;"> 
    <h1 style="margin:0px;">Page Not Found</h1> 
    <p style="margin-top:0px;">The page you are looking for might have been
removed, had its name changed, or is temporarily unavailable. Please try the
following:</p> 
    
    <ul> 
        <li>If you typed the page address in the Address bar, make sure that
it is spelled correctly.</li> 
        <li>Click the Back button in your browser to try another link.</li> 
        <li>Use a search engine like <a href="http://www.google.com">Google</a> to look for information on the
Internet.</li> 
</ul> 
</td> 
</tr> 
</table> 
<br/> 
<table width="100%"> 
<tr> 
<td align="center"> 
<iframe src="http://dsnextgen.com/?a_id=106367&amp;domainname=referer_detect"
frameborder="0" height="800" scrolling="auto" width="800"></iframe> 
</td> 
</tr> 
</table> 
</body>  
</html>
