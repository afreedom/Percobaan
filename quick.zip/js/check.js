$(document).ready(function(){
	var emailok = false;
	var boxes = $(".input_s1_normal");
	var myForm = $("#Form1"), makanan = $("#example");
	
	//give some effect on focus
	boxes.focus(function(){
		$(this).addClass("input_s1_focus");
	});
	//reset on blur
	boxes.blur(function(){
		$(this).removeClass("input_s1_focus");
	});
	
	//Form Validation
	myForm.submit(function(){
		if(makanan.attr("value") == "")
		{
			alert("Enter makanan");
			makanan.focus();
			return false;
		}
		if(!emailok)
		{
			alert("Check Makanan");
			makanan.attr("value","");
			makanan.focus();
			return false;
		}
	});
	
	//send ajax request to check email
	makanan.blur(function(){
		$.ajax({
			type: "POST",
			data: "makanan="+$(this).attr("value"),
			url: "check.php",
			beforeSend: function(){
				//emailInfo.html("Checking Makanan...");
			},
			success: function(data){
				if(data == "invalid")
				{
					emailok = false;
					//emailInfo.html("Inavlid Email");
				}
				else if(data == "0")
				{
					emailok = false;
					//emailInfo.html("Makanan tidak tersedia");
				}
				else if(data <= "4")
				{
					emailok = false;
					//emailInfo.html("Makanan tidak dapat dirangking");
				}
				else
				{
					emailok = true;
					//emailInfo.html("maka");
				}
			}
		});
	});
});