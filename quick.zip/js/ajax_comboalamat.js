function kecamatan (id_fak){
	//alert(pilihan);
	
	var obj=document.getElementById("kelurahan");
	var url='proses.php?mode=kelurahan';
	url=url+'&id_kec='+id_kec
	
	xmlhttp.open("GET", url);
	
	xmlhttp.onreadystatechange = function() {
		if ( xmlhttp.readyState == 4 && xmlhttp.status == 200 ) {
			obj.innerHTML = xmlhttp.responseText;
		} else {
			obj.innerHTML = "<div align ='center'><img src='waiting.gif' alt='Loading' /></div>";
		}
	}
	xmlhttp.send(null);

}
