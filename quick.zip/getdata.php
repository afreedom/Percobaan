<?php
include("koneksi.php");
$propinsi = $_GET['propinsi'];
$query = mysql_query("SELECT distinct kota FROM tempat WHERE provinsi ='$propinsi'");
echo "<select name='kota' id=kota>";
echo "<option value=->--Pilih Kota/Kabupaten--</option></select>";
while( $data = mysql_fetch_array( $query ) ){
	echo "<option value='".$data['kota']."'>".$data['kota']."</option>";
}
echo "</select>";
?>
