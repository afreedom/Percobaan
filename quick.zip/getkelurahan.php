<?php
include("koneksi.php");
$propinsi = $_GET['kota'];
$query = mysql_query("SELECT kelurahan FROM tempat WHERE kecamatan ='$propinsi'");
echo "<select name='kelurahan' id=kelurahan>";
echo "<option value=->--Pilih Kelurahan--</option></select>";
while( $data = mysql_fetch_array( $query ) ){
	echo "<option value='".$data['kelurahan']."'>".$data['kelurahan']."</option>";
}
echo "</select>";
?>
