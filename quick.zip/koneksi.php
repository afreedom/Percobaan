<?php
$host="localhost";
$user="IAssa_afry";
$pass="admin123";
$db="iassan_koalisihebat";
$lisensi="technosindo.com";
$koneksi=mysql_connect ($host,$user,$pass) or die (mysql_error());
mysql_select_db ($db, $koneksi) or die (mysql_error());
?>
