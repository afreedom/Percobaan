<?php 

session_start ();
include('koneksi.php');
$sel=mysql_query("select max(no_urut) as nourut from waktu_login where no_petugas='$_SESSION[username]'");
$dasel=mysql_fetch_array($sel);
$waktu=date("H:i:s");
mysql_query("update waktu_login set waktu_logout='$waktu' where no_urut='$dasel[nourut]'");
session_destroy(); 


header("location:index.php"); 
?>