<?php
session_start();
include ("koneksi.php");
$lindungi_username=strip_tags($_POST["username"]);
$lindungi_password=strip_tags($_POST["password"]);
if ((!$_POST["username"]) or (!$_POST["password"]) or (!$_POST["kode"])) {
		
		?>
			echo "<script>window.alert('DATA MASIH ADA YANG KOSONG'); window.location=('index.php')</script>";
		<?php
			 	
	} 
	elseif ($_POST["kode"]!=$_POST["cap"]) {
	//	header ("location:index.php");
		$kode=$_POST["kode"];
		//echo "$kode";
		$cap=$_SESSION['captcha']['code'];
		?>
		<script>window.alert('MAAF KODE SALAH'); window.location=('index.php')</script>
		<?php	 	
	} 
else {
	$username=$_POST["username"];
	$password=$_POST["password"];
	$pass=md5($password);
	
	if ($username=="admin" and $password=="admin") {
	
		$_SESSION["username"]=$username;
		$_SESSION["password"]=$password;
		$_SESSION["kategori"]="admpusat";
		//$_SESSION["cabang"]=$_POST['postugas'];
		
	//	session_register("username", "password", "kategori");
		
				$quelog=mysql_query("select max(no) as n, max(no_urut) as nourut from waktu_login");
				$dalog=mysql_fetch_array($quelog);
				$no_urut=$dalog['nourut']+1;
				$jam=date('H:i:s');
				$que=mysql_query("INSERT INTO waktu_login (tanggal_login,no_urut,no_petugas,waktu_login) values (sysdate(),'$no_urut','$_SESSION[username]','$jam')");
				
				if($que){
				//echo"berhasil";
				}
				else{
				//echo"gagal";
				}
				header ("location:admpusat.php");
		
		
	} 
	else {
		header ("location:index.php");
	}
}
?>