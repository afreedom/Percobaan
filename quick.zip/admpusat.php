<?php 
session_start(); 
ob_start();
if (empty ($_SESSION["username"]) and empty ($_SESSION["password"])) {
	header("location:logout.php"); 
}
elseif ($_SESSION["kategori"]!="admpusat") {
	header("location:logout.php"); 
}
else {
include ("koneksi.php");
	include ("function/function.php");
	$tampil="ok";
	$halaman="admpusat";

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Quick Count </title>
      <link href="style/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="style/bootstrap.css" rel="stylesheet" type="text/css" />

	<link href="style/bootstrap-responsive.css" rel="stylesheet">
	
</head>
<body topmargin="0" bottommargin="0">

<div class="container">

	<div class="navbar-inner">
	   <h1><font color=#fff>Quick Count</font></h1>
	</div>
    <?php 
	
	echo"<div class=row>";

 echo"<a href=logout.php><button type=button class=\"btn btn-danger\">Logout</button></a><br><hr></hr>";
	echo"<form action=# method=POST name=ajaxform id=ajaxform>";
	echo"<span class='table4'>Provinsi <br> ";
	  $query = mysql_query("SELECT distinct provinsi FROM tempat");
echo "<select name=propinsi id=propinsi>";
echo "<option value='-'>--Pilih Provinsi--</option>";
while( $data = mysql_fetch_array( $query ) ){
	echo "<option value='".$data['provinsi']."'>".$data['provinsi']."</option>";
}
echo "</select>";
echo "<br>Kota<br>
<select name=kota id=kota>
<option>--Pilih Kabupaten/Kota--</option>
";
echo"</select><br>Kecamatan<br><select name=kecamatan id=kecamatan>
<option value=->--Pilih Kecamatan--</option></select>";

echo"</select><br>Kelurahan<br><select name=kelurahan id=kelurahan>
<option value=->--Pilih Kelurahan--</option></select>";
	echo"<br>Suara Jokowi <br><input type=text name=jokowi id=jokowi onkeypress=\"return harusangka(event)\" required><br>";
	echo"Suara Prabowo <br><input type=text name=prabowo id=prabowo onkeypress=\"return harusangka(event)\" required><br>";
	echo"<input type=submit value=Simpan class=\"btn btn-primary\" name=simp id=simp onclick=\"return cekinput()\">";
	echo"<br><br><br><span name=Berhasil id=Berhasil style=\"color:#fff;padding:15px;background:#ff0000;margin-top:15px;\"></span>";
	echo"</form>";


	echo"</div>";
	echo"<footer>";	
		echo"Powered By : <a href=www.technosindo.com>Technosindo</a>";
	echo"</footer>";	
	?>


</div>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery-1.8.2.min.js"></script>
   
	<script type="text/javascript" src="js/jquery.validate.min.js"></script>
		<script type="text/javascript">
		function ambil_kota(id_prov){
			$.ajax({
				url: "getdata.php?id_prov="+id_prov,
				success: function(msg){
					$('.kota').html(msg);
				},
				dataType: "html"
			});
		}
		$(document).ready(function() {
			$('#cek').validate({
				rules: {
					telepon : {
						digits: true,
						minlength:10,
						maxlength:12
					},
					kodepos : {
						digits: true,
						minlength:5
						
					},
					
					
				
					domain: {
						url: true
					}
			
				},
				messages: {
					telepon: {
						required: "Kolom no hp harus diisi",
						minlength: "Kolom no handphone harus terdiri dari min 10 digit",
						maxlength: "Kolom no handphone harus terdiri dari max 13 digit"
					},
					kodepos: {
						required: "Kolom kode pos harus diisi",
						minlength: "Kolom kode pos harus terdiri dari min 5 digit",
						
					},
					prabowo: {
						required: "Suara Prabowo harus diisi",
						
					},
jokowi: {
						required: "Suara Jokowi harus diisi",
						
					},
					email: {
						required: "Alamat email harus diisi",
						email: "Format email tidak valid"
					},
					
				}
			});
				$("#propinsi").change(function(){
				var propinsi = $("#propinsi").val();
				$.ajax({
				url: "getdata.php",
				data: "propinsi="+propinsi,
				cache: false,
				success: function(msg){
				//jika data sukses diambil dari server kita tampilkan
				//di
				
				$("#kota").html(msg);
				}
				});
			});
			$("#kecamatan").change(function(){
				var kota = $("#kecamatan").val();
				$.ajax({
				url: "getkelurahan.php",
				data: "kota="+kota,
				cache: false,
				success: function(msg){
				//jika data sukses diambil dari server kita tampilkan
				//di
				
				$("#kelurahan").html(msg);
				}
				});
			});
			$("#kota").change(function(){
				var kota = $("#kota").val();
				$.ajax({
				url: "getkecamatan.php",
				data: "kota="+kota,
				cache: false,
				success: function(msg){
				//jika data sukses diambil dari server kita tampilkan
				//di
				
				$("#kecamatan").html(msg);
				}
				});
			});
			$("#ajaxform").submit(function(e)
			{
var kels=$('#kelurahan').val()
		
		if(kels==''){alert('Masukan Kelurahan !');return false;}
		else if(kels=='-'){alert('Masukan Kelurahan !');return false;}
				var kel = $("#kelurahan").val();
var kec = $("#kecamatan").val();
var kota = $("#kota").val();
var pro = $("#propinsi").val();
var datakel=pro+"."+kota+"."+kec+"."+kel;
				var jokowi = $("#jokowi").val();
				var prabowo = $("#prabowo").val();
                              
				var postData = $("#ajaxform").serializeArray();
				var link = "http://www.enervolution.com/jokowi/sendQuickCount.php?kelurahan="+datakel+"&jokowi="+jokowi+"&prabowo="+prabowo;
				$.ajax(
				{
					url : link,
					type: "POST",
					data : postData,
					success:function(data) 
					{
						//data: return data from server
						$("#Berhasil").html('OK');
					},
					error: function(data) 
					{
						$("#Berhasil").html("DATA BERHASIL DISIMPAN");
						//if fails      
					}
				});
				e.preventDefault(); //STOP default action
				
				
			});
		});
		
		$.validator.addMethod(
			"indonesianDate",
			function(value, element) {
				// put your own logic here, this is just a (crappy) example
				return value.match(/^\d\d?\/\d\d?\/\d\d\d\d$/);
			},
			"Please enter a date in the format DD/MM/YYYY"
		);
		
		</script>
		 <script type="text/javascript">

function harusangka(jumlah){
  var karakter = (jumlah.which) ? jumlah.which : event.keyCode
  if (karakter > 31 && (karakter < 48 || karakter > 57))
    return false;

  return true;
}
function cekinput() {
		
		
	}
		
 </script>
</body>
</html>
<?php
}
?>
